const TOKEN = process.env.MAILERLITE_TOKEN || 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI0IiwianRpIjoiYjYxMTQ3NmVlOTBiZDg2MzU1OTBkZDMxZjdkZTZhY2NkZjg3NjM4MWQ2ODA2ZGQ2YzVmZDE2ZWUxNTM1MzYyYmE1NTYwNmFhODIxMDExMzgiLCJpYXQiOjE3Nzg0MTExOTcuNzIzOTc3LCJuYmYiOjE3Nzg0MTExOTcuNzIzOTgsImV4cCI6NDkzNDA4NDc5Ny43MTQ0Niwic3ViIjoiMjM1MzIzNyIsInNjb3BlcyI6W119.lU_Jl0stg78SRPh2w_y2vbR43eX7HtuNpmEsyphANCzNifA4-g4frkVtqDo0yjbwxK-_HmvvIxLTCp_Et4EvgZJAeUJAx6OPWXJCx6hOdIK19wrtclS8ch7wPI2vUZo5aaqQDxvgnmZ-VnmKL7QWWFyL4DagKfdE27DlnY45_LBHmSkiMluLf9lWef_4pYdDkH3rG4L6-7GbbYI3DcrbRlJNDBSEgvv0wR2KISR2B6iCsns_21H_iXzPxrJezEj4E8CyaIqwn7TwmYKL60Taox2W8e7m6S3LXb2iQvzjHfwZdsDeXSwyigQduyfoPNTmuv2p6cfuzh-U9eCYD6J44NdxTh70PE8gfh2ivRp_RoHJ6YBDGlecW_hT55G6NI5nG8DC_z8FLLhqA7Gj5_3ZbAFGSWaqDMgzUtj2eI3a1irOlMuNnLYvFhEn302NqyFm2Ii-Km9XaRlJemOdvXvyqsJnetNwKs8L278DiH2LN-4RKSMaOcdq9U2E1Im_9ZfygxFSfWq5OkS5d25Zbmrx1du2meW4DxJyMlPLrctR_Rq6PYYl2iVY7Cc4tpZMmZXXZJNzWCHi5iO5K6Ql4E1RbOs-DF69bWbLoRr8ExVcgImz_N3cMPOMEod_IFUnEtbPZhKoo7QjrJ1Ljpx-gjcdtlVTjmVH0Rj9FOIJHgZS67mk';
const GROUP_ID = '187079609224791396';
const API = 'https://connect.mailerlite.com/api';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json'
};

// Custom fields potrzebne w MailerLite
// Tworzone automatycznie przy pierwszym użyciu
const CUSTOM_FIELDS = [
  { name: 'Pojazd',       key: 'pojazd',       type: 'text' },
  { name: 'Usługa',       key: 'usluga',       type: 'text' },
  { name: 'Data serwisu', key: 'data_serwisu', type: 'date' },
  { name: 'Powłoka',      key: 'powloka',      type: 'text' },
];

async function mlFetch(path, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${TOKEN}`
    }
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API}${path}`, opts);
  let data = null;
  try { data = await res.json(); } catch(e) {}
  return { ok: res.ok, status: res.status, data };
}

async function ensureCustomFields() {
  // Pobierz istniejące pola
  const { data } = await mlFetch('/fields?limit=100');
  const existing = (data?.data || []).map(f => f.key);

  for (const field of CUSTOM_FIELDS) {
    if (!existing.includes(field.key)) {
      await mlFetch('/fields', 'POST', { name: field.name, type: field.type });
    }
  }
}

exports.handler = async function(event) {
  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: CORS_HEADERS, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const data = JSON.parse(event.body);

    if (!data.email) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'Email jest wymagany' })
      };
    }

    // Upewnij się że custom fields istnieją w MailerLite
    await ensureCustomFields();

    const [first_name, ...rest] = (data.name || '').split(' ');
    const last_name = rest.join(' ');

    // Data serwisu — dziś jeśli nie podano
    const dataSerwisu = data.dataSerwisu || new Date().toISOString().split('T')[0];

    const payload = {
      email: data.email,
      fields: {
        // Standardowe pola MailerLite
        name:      first_name || '',
        last_name: last_name  || '',
        phone:     data.tel   || '',
        // Custom fields Hiline
        pojazd:       data.car     || '',
        usluga:       data.usluga  || '',
        data_serwisu: dataSerwisu,
        powloka:      data.powloka || data.usluga || '',
      },
      groups: [GROUP_ID],
      status: 'active'
    };

    const { ok, status, data: result } = await mlFetch('/subscribers', 'POST', payload);

    if (!ok) {
      console.error('MailerLite error:', result);
      return {
        statusCode: status,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: result?.message || 'Błąd MailerLite' })
      };
    }

    console.log('Subscriber saved:', result?.data?.id, data.email);

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({ success: true, id: result?.data?.id })
    };

  } catch (err) {
    console.error('Function error:', err.message);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message })
    };
  }
};
